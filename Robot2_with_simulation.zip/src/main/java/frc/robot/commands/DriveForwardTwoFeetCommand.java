// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.subsystems.DriveTrainSubsystem;

public class DriveForwardTwoFeetCommand extends CommandBase {

  int counter = 0;
  // Reference to the constructed drive train from RobotContainer to be
  // used to drive our robot
  private final DriveTrainSubsystem m_driveTrain;
  private boolean m_driveComplete;
  private double driveSpeed = 0.3;
  private double driveDistanceInches = 3 * 39.37; // 39.37 inches per meter

  /** Creates a new DriveForwardTwoFeetCommand. */
  public DriveForwardTwoFeetCommand(DriveTrainSubsystem driveTrain) {
    // Use addRequirements() here to declare subsystem dependencies.

    m_driveTrain = driveTrain;
    addRequirements(m_driveTrain);
  }

  // Called when the command is initially scheduled.
  @Override
  public void initialize() {
    m_driveComplete = m_driveTrain.driveForwardInches(driveSpeed, driveDistanceInches, true);

    // System.out.println("Drive Forward - reset encoder in command " + m_driveTrain.getTimer1Value() + "  Enc: "
    //     + m_driveTrain.getRightEncoderValue());

  }

  // Called every time the scheduler runs while the command is scheduled.
  @Override
  public void execute() {
    m_driveComplete = m_driveTrain.driveForwardInches(driveSpeed, driveDistanceInches, false);

    counter = counter + 1;
    if (counter > 10) {
    //  System.out
    //      .println("Drive Forward: " + m_driveTrain.getTimer1Value() + "  Enc: " + m_driveTrain.getRightEncoderValue());
      counter = 0;
    }

  }

  // Called once the command ends or is interrupted.
  @Override
  public void end(boolean interrupted) {
    boolean not_used = m_driveTrain.driveForwardInches(0, 0, true);
    //System.out.println("Drive Forward - reset encoder in command " + m_driveTrain.getTimer1Value() + "  Enc: "
    //    + m_driveTrain.getRightEncoderValue());
  }

  // Returns true when the command should end.
  @Override
  public boolean isFinished() {
    return m_driveComplete;
  }
}
