// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.commands;

import edu.wpi.first.wpilibj2.command.CommandBase;
import frc.robot.subsystems.DriveTrainSubsystem;

public class TurnRobotToLeft90 extends CommandBase {

  // Reference to the constructed drive train from RobotContainer to be
  // used to drive our robot
  private final DriveTrainSubsystem m_driveTrain;
  private double currentGyroHeading = 0;
  private double targetGyroHeading = -90;
  private boolean TurnComplete = true;

  /** Creates a new TurnRobotToLeft90. */
  public TurnRobotToLeft90(DriveTrainSubsystem driveTrain) {
    // Use addRequirements() here to declare subsystem dependencies.
    m_driveTrain = driveTrain;
    addRequirements(m_driveTrain);
  }

  // Called when the command is initially scheduled.
  @Override
  public void initialize() {
    m_driveTrain.reset_gyro();
    System.out.println("Turn to left -- Gyro Init: " + m_driveTrain.getTimer1Value() + "  " + m_driveTrain.get_current_heading());
  }

  // Called every time the scheduler runs while the command is scheduled.
  @Override
  public void execute() {
    currentGyroHeading = m_driveTrain.get_current_heading();
    if (currentGyroHeading > targetGyroHeading) {
      m_driveTrain.manualDrive(0, -0.15); // Rotate at 50% power  (Positive turns right)
      TurnComplete = false;
    } else {
      m_driveTrain.manualDrive(0, 0);
      TurnComplete = true;
      System.out.println("Turn to left -- Turn Complete: " + m_driveTrain.getTimer1Value() + "  " + m_driveTrain.get_current_heading());
    }

  }

  // Called once the command ends or is interrupted.
  @Override
  public void end(boolean interrupted) {
    m_driveTrain.manualDrive(0, 0);
  }

  // Returns true when the command should end.
  @Override
  public boolean isFinished() {
    return TurnComplete;
  }
}
