// Copyright (c) FIRST and other WPILib contributors.
// Open Source Software; you can modify and/or share it under the terms of
// the WPILib BSD license file in the root directory of this project.

package frc.robot.subsystems;

import static frc.robot.Constants.LED_STRIP_PORT;
import static frc.robot.Constants.NUMBER_OF_LEDS;

import edu.wpi.first.wpilibj.AddressableLED;
import edu.wpi.first.wpilibj.AddressableLEDBuffer;
import edu.wpi.first.wpilibj2.command.SubsystemBase;

public class LEDSubsystem extends SubsystemBase {
  /** Creates a new LEDSubsystem. */
  private AddressableLED m_led;
  private AddressableLEDBuffer m_ledBuffer;



  public LEDSubsystem() {
      	// PWM port is defined by the constant LED_STRIP_PORT
        m_led = new AddressableLED(LED_STRIP_PORT);

        // Set the number of LEDs
        m_ledBuffer = new AddressableLEDBuffer(NUMBER_OF_LEDS);
        m_led.setLength(m_ledBuffer.getLength());
    
        // Set the data
        m_led.setData(m_ledBuffer);
        m_led.start();
    
  }

  public void SetLEDColor(int red, int green, int blue) {

    for (var index = 0; index < m_ledBuffer.getLength(); index = index + 1) {

      m_ledBuffer.setRGB(index, red, green, blue); // Red, Green, Blue
    }
    m_led.setData(m_ledBuffer);
    m_led.start();
  }


  @Override
  public void periodic() {
    // This method will be called once per scheduler run
  }
}
